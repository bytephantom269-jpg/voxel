package com.example.voxel_attendance_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
